export const NotFound = () => <div>Not Found</div>;
